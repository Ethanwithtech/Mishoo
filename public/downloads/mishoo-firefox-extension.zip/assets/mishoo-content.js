var e=`mishoo-extension-overlay-root`,t={"mishoo-cat":{name:{zh:`真实小猫 Mia`,en:`Mia the Real Cat`},video:`videos/mia-source.webm`,restLoopStart:5,image:`https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=1200&q=85`},"cocoa-dog":{name:{zh:`金毛 Cocoa`,en:`Cocoa the Golden Retriever`},video:`videos/golden-source.webm`,restLoopStart:4},"snow-rabbit":{name:{zh:`萨摩耶 Snow`,en:`Snow the Samoyed`},video:`videos/samoyed-source.webm`,restLoopStart:1},"pom-puppy":{name:{zh:`博美 Mochi`,en:`Mochi the Pomeranian`},video:`videos/pomeranian-source.webm`,restLoopStart:4},"lop-rabbit":{name:{zh:`垂耳兔 Mocha`,en:`Mocha the Lop Rabbit`},video:`videos/lop-rabbit-source.webm`,restLoopStart:4},"bamboo-panda":{name:{zh:`竹子熊猫 BaoBao`,en:`BaoBao the Bamboo Panda`},video:`videos/panda-bamboo-source.webm`,hasAlpha:!0,restLoopStart:6}},n={zh:{finish:`回到网页`,skip:`现在退出休息`,done:`休息完成`,resting:`咪咻正在守护休息时间`},en:{finish:`Back to page`,skip:`Exit break now`,done:`Break complete`,resting:`Mishoo is guarding your break`}},r=null,i=null;function a(e){let t=Math.max(0,Math.floor(e));return`${Math.floor(t/60).toString().padStart(2,`0`)}:${(t%60).toString().padStart(2,`0`)}`}function o(e){return e===`mishoo-cat`||e===`snow-rabbit`||e===`cocoa-dog`||e===`pom-puppy`||e===`lop-rabbit`||e===`bamboo-panda`?e:`cocoa-dog`}function s(e){return e===`en`?`en`:`zh`}function c(e=!1){r?.(),r=null,e&&chrome.runtime.sendMessage({type:`mishoo:overlay-closed`,payload:{skipped:e}})}function l(){let e=document.createElement(`style`);return e.textContent=`
    :host {
      all: initial;
      position: fixed;
      inset: 0;
      z-index: 2147483647;
      color-scheme: light;
      pointer-events: auto;
    }

    .mishooOverlay {
      position: fixed;
      inset: 0;
      overflow: hidden;
      background: transparent;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      user-select: none;
    }

    .mishooOverlay::after {
      content: none;
    }

    .mishooPetSourceVideo {
      position: fixed;
      left: -10px;
      top: -10px;
      width: 1px;
      height: 1px;
      opacity: 0;
      pointer-events: none;
    }

    .mishooPetCanvas,
    .mishooPetVideo {
      position: fixed;
      inset: 0;
      width: 100vw;
      height: 100vh;
      object-fit: contain;
      pointer-events: none;
      background: transparent;
      filter: drop-shadow(0 28px 42px rgba(0,0,0,0.22));
      animation: mishooFadeIn 520ms ease both;
    }

    .mishooPetImageWrap {
      position: fixed;
      left: 50%;
      bottom: 7vh;
      z-index: 2;
      width: min(46vw, 430px);
      transform: translateX(-50%);
      pointer-events: none;
      animation: mishooImageEnter 900ms cubic-bezier(.16,1,.3,1) both;
    }

    .mishooPetImageWrap img {
      display: block;
      width: 100%;
      border: 8px solid rgba(255,255,255,.88);
      border-radius: 42px;
      box-shadow: 0 32px 80px rgba(39,21,10,.28);
    }

    .mishooTimer {
      position: fixed;
      top: 18px;
      left: 18px;
      z-index: 4;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      min-height: 44px;
      padding: 8px 14px;
      border: 1px solid rgba(255,255,255,.28);
      border-radius: 999px;
      color: #fffaf4;
      background: rgba(31, 22, 16, .52);
      box-shadow: 0 16px 44px rgba(0,0,0,.18);
      backdrop-filter: blur(14px);
      font-size: 22px;
      font-weight: 950;
      letter-spacing: -.04em;
    }

    .mishooTimer small {
      max-width: 210px;
      color: rgba(255,250,244,.82);
      font-size: 12px;
      font-weight: 800;
      letter-spacing: 0;
      white-space: nowrap;
    }

    .mishooExit {
      position: fixed;
      top: 18px;
      right: 18px;
      z-index: 4;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 44px;
      padding: 0 16px;
      border: 1px solid rgba(123,75,47,.14);
      border-radius: 999px;
      color: #653019;
      background: rgba(255,255,255,.9);
      box-shadow: 0 16px 44px rgba(0,0,0,.14);
      backdrop-filter: blur(12px);
      font: 900 14px/1 Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      cursor: pointer;
    }

    .mishooFinish {
      border: 0;
      border-radius: 999px;
      color: #5b2a12;
      background: #fff4e7;
      min-height: 30px;
      padding: 0 12px;
      font: 900 13px/1 Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      cursor: pointer;
    }

    @keyframes mishooFadeIn {
      from { opacity: 0; transform: translateY(18px) scale(.985); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }

    @keyframes mishooImageEnter {
      from { opacity: 0; transform: translate(-50%, 34px) scale(.96); }
      to { opacity: 1; transform: translate(-50%, 0) scale(1); }
    }

    @media (max-width: 720px) {
      .mishooTimer small { display: none; }
      .mishooPetImageWrap { width: min(76vw, 390px); }
    }
  `,e}function u(e,t){if(!t.video)return()=>void 0;let n=document.createElement(`video`);n.src=chrome.runtime.getURL(t.video),n.autoplay=!0,n.muted=!0,n.playsInline=!0,n.preload=`auto`;let r=t.hasAlpha===!0,i=()=>{let e=typeof t.restLoopStart==`number`?t.restLoopStart:0,r=n.duration;if(!(!Number.isFinite(r)||r<=0))try{n.currentTime=Math.max(0,Math.min(e,r-.05))}catch{}};if(r){n.className=`mishooPetVideo`;let t=()=>{i(),n.play().catch(()=>void 0)},r=()=>{let e=n.duration;Number.isFinite(e)&&e>0&&n.currentTime>=e-.1&&i()},a=()=>{n.play().catch(()=>void 0)};return n.addEventListener(`loadeddata`,a),n.addEventListener(`ended`,t),n.addEventListener(`timeupdate`,r),e.append(n),n.play().catch(()=>void 0),()=>{n.removeEventListener(`loadeddata`,a),n.removeEventListener(`ended`,t),n.removeEventListener(`timeupdate`,r),n.pause(),n.removeAttribute(`src`),n.load()}}n.className=`mishooPetSourceVideo`,n.crossOrigin=`anonymous`;let a=document.createElement(`canvas`);a.className=`mishooPetCanvas`,e.append(n,a);let o=a.getContext(`2d`,{willReadFrequently:!0});if(!o)return n.className=`mishooPetVideo`,a.remove(),n.play().catch(()=>void 0),()=>{n.pause(),n.removeAttribute(`src`),n.load()};let s=0,c=!0,l=!1,u=0,d=()=>{if(!n.videoWidth||!n.videoHeight)return;let e=Math.min(1,1280/Math.max(n.videoWidth,n.videoHeight)),t=Math.max(1,Math.round(n.videoWidth*e)),r=Math.max(1,Math.round(n.videoHeight*e));(a.width!==t||a.height!==r)&&(a.width=t,a.height=r)},f=()=>{c=!1,s&&cancelAnimationFrame(s),a.remove(),n.className=`mishooPetVideo`},p=(e=performance.now())=>{if(c){if(n.readyState>=2&&n.videoWidth&&e-u>=41.666666666666664){d(),u=e;try{o.drawImage(n,0,0,a.width,a.height);let e=o.getImageData(0,0,a.width,a.height),r=e.data;for(let e=0;e<r.length;e+=4){let n=r[e+3];if(n<=4)continue;let i=r[e],a=r[e+1],o=r[e+2];if(t.chromaKey===`blue`){let t=o-i,s=a-i,c=o>75&&t>24&&s>18&&o>=a-10,l=c?Math.min(1,Math.max(0,(Math.min(t,s)-18)/34)):0;if(l>=.96||c&&t>52&&s>32){r[e+3]=0;continue}if(l>0){if(r[e+3]=Math.max(0,Math.round(n*(1-l))),r[e+3]<28){r[e+3]=0;continue}r[e+2]=Math.max(i,Math.round(o-t*.75)),r[e+1]=Math.max(i,Math.round(a-s*.45))}continue}let s=Math.max(i,o),c=Math.min(i,o),l=a-s,u=2*a-i-o,d=a-c,f=a>42&&l>7&&u>16&&d>24,p=f?Math.min(1,Math.max(0,(l-7)/34)):0;if(p>=.98||f&&l>46){r[e+3]=0;continue}if(p>0&&(r[e+3]=Math.max(0,Math.round(n*(1-p))),r[e+3]<28)){r[e+3]=0;continue}l>0&&(r[e+1]=Math.max(s,Math.round(a-l*.9)))}o.putImageData(e,0,0)}catch{f();return}}s=requestAnimationFrame(p)}},m=()=>{let e=n.duration;!Number.isFinite(e)||e<=0||(l||n.currentTime>=e-.1)&&(l=!0,i())},h=()=>{d(),n.play().catch(()=>void 0),s===0&&(s=requestAnimationFrame(p))},g=()=>{m(),n.play().catch(()=>void 0)},_=()=>{let e=n.duration;Number.isFinite(e)&&e>0&&n.currentTime>=e-.1&&m()};return n.addEventListener(`loadeddata`,h),n.addEventListener(`ended`,g),n.addEventListener(`timeupdate`,_),n.readyState>=2&&h(),n.play().catch(()=>void 0),()=>{c=!1,s&&cancelAnimationFrame(s),n.removeEventListener(`loadeddata`,h),n.removeEventListener(`ended`,g),n.removeEventListener(`timeupdate`,_),n.pause(),n.removeAttribute(`src`),n.load()}}function d(e){return/^https?:\/\//i.test(e)||e.startsWith(`data:`)||e.startsWith(`blob:`)?e:chrome.runtime.getURL(e.replace(/^\//,``))}function f(e,t,n){if(!t.image)return;let r=document.createElement(`figure`);r.className=`mishooPetImageWrap`;let i=document.createElement(`img`);i.src=d(t.image),i.alt=t.name[n],i.draggable=!1,r.append(i),e.append(r)}function p(d){c(!1);let p=o(d.pet),m=s(d.language),h=Math.max(10,Math.min(Number(d.durationSec)||300,3600)),g=d.strictMode!==!1,_=t[p],v=n[m],y=h,b=!1,x=document.createElement(`div`);x.id=e;let S=x.attachShadow({mode:`open`}),C=document.createElement(`main`);C.className=`mishooOverlay`;let w=document.createElement(`section`);w.className=`mishooTimer`;let T=document.createElement(`span`);T.textContent=a(y);let E=document.createElement(`small`);E.textContent=v.resting,w.append(T,E);let D=document.createElement(`button`);D.className=`mishooExit`,D.type=`button`,D.textContent=v.skip,D.addEventListener(`click`,()=>c(!b));let O=_.video?u(C,_):(f(C,_,m),()=>void 0);C.append(w,D),S.append(l(),C),document.documentElement.append(x);let k=window.setInterval(()=>{if(--y,y<=0&&(y=0,b=!0,E.textContent=v.done,!w.querySelector(`.mishooFinish`))){let e=document.createElement(`button`);e.className=`mishooFinish`,e.type=`button`,e.textContent=v.finish,e.addEventListener(`click`,()=>c(!1)),w.append(e)}T.textContent=a(y)},1e3);g&&(i=e=>{b||(e.preventDefault(),e.stopPropagation())},window.addEventListener(`keydown`,i,!0),window.addEventListener(`keyup`,i,!0)),r=()=>{O?.(),window.clearInterval(k),i&&=(window.removeEventListener(`keydown`,i,!0),window.removeEventListener(`keyup`,i,!0),null),document.getElementById(e)?.remove()}}chrome.runtime.onMessage.addListener((e,t,n)=>!e||typeof e!=`object`||!(`type`in e)?!1:e.type===`mishoo:show-overlay`?(p(e.payload||{}),n({ok:!0}),!0):e.type===`mishoo:close-overlay`?(c(!1),n({ok:!0}),!0):!1);